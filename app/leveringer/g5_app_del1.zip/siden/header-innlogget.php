  <div class="navHeader">
    <div class="headerNav" id="headerNav">
      <img class="logo-headerNav" src="img/logo.png" alt="Logoen til USN" width="84" height="42">
      <a href="#anonser">Anonser</a>
      <a href="#events">Sosialt</a>
      <a href="#nyheter">IT nyheter</a>
      <a href="#minSIde" right-margin="5%">Min Side</a>
    </div>
  </div>
